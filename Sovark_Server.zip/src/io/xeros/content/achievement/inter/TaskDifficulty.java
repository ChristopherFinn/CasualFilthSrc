package io.xeros.content.achievement.inter;

/**
 * Used for filtering.
 */
public enum TaskDifficulty {
    NONE, STARTER, BEGINNER, INTERMEDIATE, EXPERT, LEGENDARY
}
